import * as THREE from '../libs/three.module.js'

// NOTE descomprimir esta carpeta al nivel de la carpeta 
// ejerciciosThree que se recomendaba en practicas

import { ThreeBSP } from '../libs/ThreeBSP.js'
import * as TWEEN from '../libs/tween.esm.js'

//
// ─── Cabeza ─────────────────────────────────────────────────────────────────────
//
class Cabeza extends THREE.Mesh{

    constructor(){
        super();

        // TODO Crear geometria
        // NOTE No te olvides de hacer BufferGeometry

        var arribaBSP = mediaEsferaBSP(),
            abajoBSP  = mediaEsferaBSP();

        var cilindroGeo = new THREE.CylinderGeometry(0.25,0.25,6);
        cilindroGeo.rotateX(Math.PI/2.0);
        cilindroGeo.translate(1.5,1.5,0);

        var cilindroBSP = new ThreeBSP(cilindroGeo);

        arribaBSP = arribaBSP.subtract(cilindroBSP);

        var parteArriba = arribaBSP.toGeometry();
        var bufferGeometryArriba = new THREE.BufferGeometry().fromGeometry(parteArriba);

        var parteAbajo = abajoBSP.toGeometry();
        var bufferGeometryAbajo = new THREE.BufferGeometry().fromGeometry(parteAbajo);
        bufferGeometryAbajo.rotateZ(Math.PI);

        var material = new THREE.MeshPhongMaterial({color : 0x00FF00}); // Verde

        this.cabeza = new THREE.Mesh(bufferGeometryArriba, material);
        this.boca   = new THREE.Mesh(bufferGeometryAbajo, material);

        this.add(this.cabeza);
        this.add(this.boca);    

        // Animacion de la boca

        this.animate();
        this.create_spline();
    }


    animate(){
        var origen  = {giro: 0},
            destino = {giro: -Math.PI/4};

        var time = 0.5; //Segundos que dura la animación

        var that = this;

        var animacion = new TWEEN.Tween(origen)
            .to(destino, time*1000)
            .easing(TWEEN.Easing.Quadratic.InOut)
            .repeat(Infinity)
            .yoyo(true)
            .onUpdate(
                function(){
                    // USA EL THAT
                    that.boca.rotation.z = origen.giro;
                }
            );

        // Comenzamos la animacion
        animacion.start();
    }

    create_spline(){
        var pts       = [
            new THREE.Vector3(-12,1,-16),
            new THREE.Vector3(-12,1,0),
            new THREE.Vector3(-12,1,20),
            new THREE.Vector3(-4,1,20),
            new THREE.Vector3(4,1,16),
            new THREE.Vector3(8,1,12),
            new THREE.Vector3(8,1,8),
            new THREE.Vector3(4,1,4),
            new THREE.Vector3(-4,1,0),
            new THREE.Vector3(-4,1,-16),
            new THREE.Vector3(-12,1,-16)
        ];

        var spline = new THREE.CatmullRomCurve3(pts);
    
        var geometryLine          = new THREE.Geometry();
        geometryLine.vertices     = spline.getPoints(100);
        var material              = new THREE.LineBasicMaterial({color: 0xff0000});
        var visibleSpline         = new THREE.Line(geometryLine, material);
        this.add(visibleSpline);
        
        return spline;
    }

    //
    // ─── METODO UPDATE ──────────────────────────────────────────────────────────────
    //        
    update () {
        TWEEN.update()
    }

}

function mediaEsferaBSP(){
    var esferaGeo = new THREE.SphereGeometry(3,30,30),
        cajaGeo   = new THREE.BoxGeometry(6,6,6);

    cajaGeo.translate(0,-3,0);

    var esferaBSP = new ThreeBSP(esferaGeo),
        cajaBSP  = new ThreeBSP(cajaGeo);

    var finalResult = esferaBSP.subtract(cajaBSP);

    return finalResult;
}


// ────────────────────────────────────────────────────────────────────────────────

export { Cabeza }

    
